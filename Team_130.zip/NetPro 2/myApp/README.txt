- Replace the folders "views" and "public" in your projects with the folders in this zip file.

- "views" folder contains all the .ejs files written in HTML, "public" folder contains all the images needed for the project.

- You won't be able to GET or POST the .ejs files until you configure them correctly in the app.js file.

- You will have to get the videos yourself, rename them according to the names in the .ejs files, and put them in the "public" folder OR you can embed them from youtube or any other website.