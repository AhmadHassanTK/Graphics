var express = require('express');
var path = require('path');
var fs = require('fs'); 
var search300;
const { nextTick, setUncaughtExceptionCaptureCallback, on } = require('process');
const { table, Console } = require('console');

//fs.writeFileSync("users.json","");
var app = express();
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
////
const TWO_HOURS =1000*60*60*2 ;
var session = require('express-session');
const { names } = require('debug');
const{
  PORT= 3000,
  NODE_ENV ='development',
  SESS_NAME='sid',
  SESS_SECRET="mwhfjklwfbkjwbqjk",
  SESS_LIFETIME=TWO_HOURS
}=process.env
const IN_PROD =NODE_ENV=='production'

app.use(session({
 // name: SESS_NAME,
  resave:false,
  saveUninitialized: false,
  secret:SESS_SECRET,
  cookie : {
    maxAge : SESS_LIFETIME,
    sameSite: true,
    secure: IN_PROD
  }
}));
////
/*app.use((req,res,next)=>{
  var zz = JSON.parse(fs.readFileSync("users.json"));
  const{userId}=req.session;
  console.log(userId);
  if(userId){
    res.locals.user=zz.find ( user=>user.name==userId)
  }
  next();
})*/
/*const redirectLogin=(req,res,next)=>{
  if(!req.session.userId){
    res.redirect('/login');
  }else{next()}
}*/
app.get('/login',function(req,res){
  req.session.destroy();
  //res.clearCookie(SESS_NAME);
  res.render('login',{message:""});
 });

app.get('/home',function(req,res){
  //const{userId}=req.session;
  res.render('home');
 });
app.get('/',function(req,res){
  //console.log(req.session);
  req.session.destroy();
  res.clearCookie(SESS_NAME);
  res.render('login',{message:""});
});

//var a;
app.post('/',function(req,res){
var x ={username:req.body.username,password:req.body.password};
var y= fs.readFileSync("users.json") ;
if(y.includes(JSON.stringify(x))){
  //req.session.c=x.username;
  req.session.userId=x.username;
  req.session.save();
  //res.locals.user=x.username;
  res.render('home');
}else{
  res.render('login',{message:"incorrect information"});
}

});
/*app.post('/login',function(req,res){
  var x ={username:req.body.username,password:req.body.password};
  var y= fs.readFileSync("users.json") ;
  if(y.includes(JSON.stringify(x))){
    //req.session.c=x.username;
    req.session.userId=x.username
   // req.session.name=x.username
    res.render('home');
  }else{
    res.render('login',{message:"incorrect information"});
  }
  
  });*/

 app.get('/registration',function(req,res){
  res.render('registration',{message:""});
 });

 app.get('/novel',function(req,res){
  res.render('novel');
 });

 app.get('/poetry',function(req,res){
  res.render('poetry');
 });
 app.get('/fiction',function(req,res){
  res.render('fiction');
 });
 app.get('/readlist',function(req,res){
  res.render('readlist',{message:req.session.userId});
 });
 app.get('/sun',function(req,res){
  //const{userId}=res.locals;
  res.render('sun',{message:req.session.userId});
 // console.log(req.session.c);
 });

 app.get('/mockingbird',function(req,res){
  res.render('mockingbird',{message:req.session.userId});
 });
 app.get('/leaves',function(req,res){
  res.render('leaves',{message:req.session.userId});
 });
 app.get('/grapes',function(req,res){
  res.render('grapes',{message:req.session.userId});
 });
 app.get('/flies',function(req,res){
  res.render('flies',{message:req.session.userId});
 });
 app.get('/dune',function(req,res){
  res.render('dune',{message:req.session.userId});
 });
 
 
 //fs.writeFileSync("users.json","");
 var z = fs.readFileSync("users.json");
 fs.writeFileSync("users.json",z);
 var data =[];
 if(z=="")
 {//data.table.push(z);
}
 else{
   var k =JSON.parse(z);
   for(let i=0;i<k.length;i++){data.push(k[i]);}
  //data.push(JSON.parse(z));
 }

 app.post('/register',function(req,res){
  var x ={username:req.body.username,password:req.body.password}; 
  var y= fs.readFileSync("users.json");

 if(y.includes(JSON.stringify(x.username)) || x.password=="" || x.username==""  ){ 
 res.render("registration", {message:"acount already exixt"});
 //res.render('registration');
 }
 else{
  data.push(x);
  fs.writeFileSync("users.json",JSON.stringify(data));
  res.redirect('/');
 }
 
  
 });
 app.get('/searchresults',function(req,res){
  search300 = req.body.Search
  res.render('searchresults' , {message2:search300});
 });


//////////////////////////////////



 app.post('/search',function(req,res){
  search300 = req.body.Search
 res.render('searchresults' , {message2:search300});
 });


 if(process.env.PORT){
  app.listen(process.env.PORT,function(){console.log('Server started')});

}else{
  app.listen(3000,function(){console.log('Server started on port 3000')});
}
