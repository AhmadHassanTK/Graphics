var x;
var i;
x=document.getElementById("o").innerText;
if(!document.getElementById("ee")){
let charts = document.querySelectorAll('.readlist');
let book = document.getElementById("title").innerText;
console.log(book);

let books =[
    {name:'sun',tag:'The Sun and Her Flowers'},
    {name:'leaves',tag:'Leaves of Grass'},
    {name:'flies',tag:'Lord of the Flies'},
    {name:'grapes',tag:'The Grapes of Wrath'},
    {name:'dune',tag:'Dune'},
    {name:'mockingbird',tag:'To Kill a Mockingbird'}
]
if(book){
    if(book=="The Sun and Her Flowers"){i=0;}
    if(book=="Leaves of Grass"){i=1;}
    if(book=="Lord of the Flies"){i=2;}
    if(book=="The Grapes of Wrath"){i=3;}
    if(book=="Dune"){i=4;}
    if(book=="To Kill a Mockingbird"){i=5;}
    x=document.getElementById("o").innerText;
    
}
function test(){
if(charts[0]&&book&&localStorage.getItem(x)){
    let f=localStorage.getItem(x);
    f=JSON.parse(f);
    //console.log(x);
    var y=JSON.stringify(Object.values(f));
    //console.log(y);
    if(y.includes(JSON.stringify(books[i]))){
       var w= document.getElementById("m").style.display="flex";
       
    }
}}

/////////
if(charts[0] != null){
charts[0].addEventListener('click',()=>{
    test();
  setItems(books[i]);
 })}
 
 function setItems(product){
    let cartItems=localStorage.getItem(x);
    cartItems=JSON.parse(cartItems);
    if(cartItems != null){
        if(cartItems[product.name]==undefined){
            cartItems={...cartItems,[product.name]:product}
        }
    }
    else{
        cartItems={[product.name]:product}
    }
    localStorage.setItem(x,JSON.stringify(cartItems))
}
}
function displayCart(){
    x=document.getElementById("o").innerText;
    let cartItems=localStorage.getItem(x);
    cartItems=JSON.parse(cartItems);
    let productContainer=document.querySelector(".products-container");
    //console.log(productContainer);
    if(cartItems && productContainer){
        productContainer.innerHTML='';
        Object.values(cartItems).map(item =>{
            productContainer.innerHTML+=`
            <div class="product">
            <img id="image" src="/${item.name}.jpg" width="193" height="300">
            <br>
            <label id ="label2" class="ml-4 my-2">${item.tag}</label>
            <br>
            <button onclick="location.href = '/${item.name}';" id="leaves" class="btn btn-secondary ml-3"> View </button>
            </div>
            `
        })
    }
    }displayCart();

    






        