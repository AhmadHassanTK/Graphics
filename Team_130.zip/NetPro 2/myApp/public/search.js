var x = document.getElementById("s").innerText;
//console.log(x);
let y =   [ {name:'sun',tag:'The Sun and Her Flowers'},
{name:'leaves',tag:'Leaves of Grass'},
{name:'flies',tag:'Lord of the Flies'},
{name:'grapes',tag:'The Grapes of Wrath'},
{name:'dune',tag:'Dune'},
{name:'mockingbird',tag:'To Kill a Mockingbird'}
]
var result = [];

for ( let i = 0 ; i<y.length ; i++){
    var x1 = y[i].tag.toLowerCase();
    var x2 = x.toLowerCase();
    var z = x1.includes(x2);
    if(z){
        result.push(y[i]);
    }
}
console.log(result);

function displayResults(res){
    let productContainer=document.querySelector(".products-result");
   // console.log(productContainer);
    if(res && productContainer){
        productContainer.innerHTML='';
        Object.values(res).map(res =>{
            productContainer.innerHTML+=`
            <div class="results">
            <img id="image" src="/${res.name}.jpg" width="193" height="300">
            <br>
            <label id ="label2" class="ml-4 my-2">${res.tag}</label>
            <br>
            <button onclick="location.href = '/${res.name}';" id="leaves" class="btn btn-secondary ml-3"> View </button>
            </div>
            `
        })
       


    }

       


    
    
}

if(result.length>0){
    displayResults(result);
}else{
    alert("Book not found");
    let productContainer=document.querySelector(".products-result");
    productContainer.innerHTML='';
    productContainer.innerHTML+=`
            <div class="results">
            Book not found
            </div>
            `
}